﻿namespace TimeCats.Models
{
    public class Dashboard
    {
        public int groupID { get; set; }

        public string groupName { get; set; }

        public int courseID { get; set; }

        public string courseName { get; set; }

        public int projectID { get; set; }

        public string projectName { get; set; }

        public int instructorId { get; set; }

        public string instructorName { get; set; }
    }
}