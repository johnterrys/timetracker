﻿namespace TimeCats.Enums
{
    public enum UserType
    {
        Admin,
        Instructor,
        Standard
    }
}